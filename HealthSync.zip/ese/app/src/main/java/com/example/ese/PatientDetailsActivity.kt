package com.example.ese

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ese.databinding.ActivityPatientDetailsBinding
import com.google.firebase.firestore.FirebaseFirestore

class PatientDetailsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPatientDetailsBinding
    private lateinit var appointmentsCollection: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPatientDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firestore
        appointmentsCollection = FirebaseFirestore.getInstance()

        // Set click listener for submit button
        binding.buttonSubmit.setOnClickListener { submitAppointment() }
    }

    private fun submitAppointment() {
        // Get patient details from EditText fields
        val name = binding.editTextName.text.toString().trim()
        val age = binding.editTextAge.text.toString().trim().toIntOrNull() ?: return
        val gender = binding.spinnerGender.selectedItem.toString()
        val appointmentDate = binding.editTextAppointmentDate.text.toString().trim()
        val symptoms = binding.editTextSymptoms.text.toString().trim()

        // Check if any field is empty
        if (name.isEmpty() || appointmentDate.isEmpty() || symptoms.isEmpty()) {
            showToast("Please fill in all fields")
            return
        }

        // Create a data object representing the appointment
        val appointmentData = hashMapOf(
            "name" to name,
            "age" to age,
            "gender" to gender,
            "appointmentDate" to appointmentDate,
            "symptoms" to symptoms
        )

        // Add the appointment data to Firestore
        appointmentsCollection
            .collection("appointments")
            .add(appointmentData)
            .addOnSuccessListener { documentReference ->
                // Document added successfully
                showToast("Appointment booked successfully")
                finish() // Close activity after booking appointment
            }
            .addOnFailureListener { e ->
                // Error adding document
                showToast("Failed to book appointment: ${e.message}")
            }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
