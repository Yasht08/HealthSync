package com.example.ese

import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.firebase.firestore.FirebaseFirestore

class ConsultationActivity : AppCompatActivity() {

    private lateinit var disease1Checkbox: CheckBox
    private lateinit var disease2Checkbox: CheckBox
    private lateinit var disease3Checkbox: CheckBox
    private lateinit var disease4Checkbox: CheckBox
    private lateinit var consultButton: Button

    private val CHANNEL_ID = "Doctor_Assigned"
    private val NOTIFICATION_ID = 123

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultation)

        // Initialize views
        disease1Checkbox = findViewById(R.id.disease1Checkbox)
        disease2Checkbox = findViewById(R.id.disease2Checkbox)
        disease3Checkbox = findViewById(R.id.disease3Checkbox)
        disease4Checkbox = findViewById(R.id.disease4Checkbox)
        consultButton = findViewById(R.id.consultButton)

        // Set onClickListener for Consult button
        consultButton.setOnClickListener {
            // Get consultation data from checkboxes
            val consultationData = StringBuilder()
            if (disease1Checkbox.isChecked) {
                consultationData.append("Fever, ")
            }
            if (disease2Checkbox.isChecked) {
                consultationData.append("Cough, ")
            }
            if (disease3Checkbox.isChecked) {
                consultationData.append("Tuberculosis, ")
            }
            if (disease4Checkbox.isChecked) {
                consultationData.append("Hypertension, ")
            }

            // Remove trailing comma and space
            var data = consultationData.toString().trim()
            if (data.endsWith(", ")) {
                data = data.substring(0, data.length - 2)
            }

            // Add consultation data to Firestore
            val db = FirebaseFirestore.getInstance()
            val consultation = hashMapOf(
                "data" to data
            )

            db.collection("consultations")
                .add(consultation)
                .addOnSuccessListener { documentReference ->
                    // Consultation data added successfully, now display notification
                    createNotificationChannel() // Create notification channel
                    val selectedDisease = getSelectedDisease()
                    val randomDoctorName = getRandomDoctorName(selectedDisease)
                    showNotification(selectedDisease, randomDoctorName)
                }
                .addOnFailureListener { e ->
                    // Handle failure
                }
        }
    }

    // Method to create notification channel
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = getString(R.string.channel_name)
            val descriptionText = getString(R.string.channel_description)
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            val notificationManager: NotificationManager =
                getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    // Method to generate random doctor name based on selected disease
    private fun getRandomDoctorName(selectedDisease: String): String {
        // Create a map of diseases to lists of doctor names
        val doctorMap = mapOf(
            "Fever" to listOf("Dr. John Doe", "Dr. Jane Smith", "Dr. Michael Johnson"),
            "Cough" to listOf("Dr. Emily Brown", "Dr. David Wilson", "Dr. Sarah Martinez"),
            "Tuberculosis" to listOf("Dr. Christopher Taylor", "Dr. Olivia Anderson", "Dr. Ethan Garcia"),
            "Hypertension" to listOf("Dr. Sophia Hernandez", "Dr. Jacob Moore", "Dr. Ava Lee")
        )

        // Get the list of doctor names corresponding to the selected disease
        val doctorsForDisease = doctorMap[selectedDisease]

        // If the list is not null and not empty, randomly select a doctor name
        return doctorsForDisease?.let {
            if (it.isNotEmpty()) {
                val randomIndex = (0 until it.size).random()
                it[randomIndex]
            } else {
                "Unknown Doctor"
            }
        } ?: "Unknown Doctor"
    }

    // Method to get the selected disease
    private fun getSelectedDisease(): String {
        if (disease1Checkbox.isChecked) {
            return "Fever"
        }
        if (disease2Checkbox.isChecked) {
            return "Cough"
        }
        if (disease3Checkbox.isChecked) {
            return "Tuberculosis"
        }
        if (disease4Checkbox.isChecked) {
            return "Hypertension"
        }
        return ""
    }

    // Method to display notification
    private fun showNotification(selectedDisease: String, doctorName: String) {
        // Create and display a notification
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Doctor Assigned")
            .setContentText("You will be assisted by Dr. $doctorName for $selectedDisease")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        with(NotificationManagerCompat.from(this)) {
            notify(NOTIFICATION_ID, builder.build())
        }
    }
}
