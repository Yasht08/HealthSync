data class Appointment(
    val name: String,
    val age: Int,
    val gender: String,
    val appointmentDate: String,
    val symptoms: String
)
