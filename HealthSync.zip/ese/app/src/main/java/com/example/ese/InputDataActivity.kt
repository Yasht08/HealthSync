package com.example.ese

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import kotlin.math.pow

class InputDataActivity : AppCompatActivity() {

    private lateinit var editTextWeight: EditText
    private lateinit var editTextHeight: EditText
    private lateinit var buttonCalculateBMI: Button
    private lateinit var textViewBMIResult: TextView
    private lateinit var textViewCategoryResult: TextView
    private lateinit var smallVideoView: VideoView
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_input_data)

        // Initialize Firestore
        firestore = FirebaseFirestore.getInstance()

        // Initialize views
        editTextWeight = findViewById(R.id.editTextWeight)
        editTextHeight = findViewById(R.id.editTextHeight)
        buttonCalculateBMI = findViewById(R.id.buttonCalculateBMI)
        textViewBMIResult = findViewById(R.id.textViewBMIResult)
        textViewCategoryResult = findViewById(R.id.textViewCategoryResult)
        smallVideoView = findViewById(R.id.smallVideoView)

        // Set video file path
        val videoPath = "android.resource://" + packageName + "/" + R.raw.vid1

        // Set video URI
        val videoUri = Uri.parse(videoPath)

        // Set video URI to the VideoView
        smallVideoView.setVideoURI(videoUri)

        // Set looping
        smallVideoView.setOnPreparedListener { mp -> mp.isLooping = true }

        // Start playing the video
        smallVideoView.start()

        // Set OnClickListener for the Calculate BMI button
        buttonCalculateBMI.setOnClickListener {
            calculateBMI()
        }
    }

    private fun calculateBMI() {
        // Get weight and height values from input fields
        val weightText = editTextWeight.text.toString()
        val heightText = editTextHeight.text.toString()

        // Check if weight and height are not empty
        if (weightText.isNotEmpty() && heightText.isNotEmpty()) {
            val weight = weightText.toFloat()
            val height = heightText.toFloat()

            // Calculate BMI
            val bmi = calculateBMIValue(weight, height)

            // Display BMI result
            textViewBMIResult.text = String.format("BMI: %.2f", bmi)

            // Categorize BMI and display category
            val category = categorizeBMI(bmi)
            textViewCategoryResult.text = "Category: $category"

            // Store data in Firestore
            storeData(weight, height, bmi, category)
        } else {
            // Handle empty input fields
            textViewBMIResult.text = "Please enter weight and height"
            textViewCategoryResult.text = ""
        }
    }

    private fun calculateBMIValue(weight: Float, height: Float): Float {
        return weight / (height / 100).pow(2)
    }

    private fun categorizeBMI(bmi: Float): String {
        return when {
            bmi < 18.5 -> "Underweight"
            bmi < 24.9 -> "Normal weight"
            bmi < 29.9 -> "Overweight"
            else -> "Obese"
        }
    }

    private fun storeData(weight: Float, height: Float, bmi: Float, category: String) {
        // Create a new document with a generated ID
        val data = hashMapOf(
            "weight" to weight,
            "height" to height,
            "bmi" to bmi,
            "category" to category
        )

        // Add a new document with a generated ID
        firestore.collection("userData")
            .add(data)
            .addOnSuccessListener { documentReference ->
                println("DocumentSnapshot added with ID: ${documentReference.id}")
            }
            .addOnFailureListener { e ->
                println("Error adding document: $e")
            }
    }
}
