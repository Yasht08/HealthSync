package com.example.ese

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.ese.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase Auth
        firebaseAuth = FirebaseAuth.getInstance()

        // Set click listener for login button
        binding.loginButton.setOnClickListener {
            val email = binding.emailEt.text.toString()
            val password = binding.passET.text.toString()

            if (email.isEmpty() || password.isEmpty()) {
                showToast("Please enter email and password")
            } else {
                // Check if the user exists in the Firebase database
                // For simplicity, you can use Firebase Authentication for user login
                // If the user is present in the Firebase Authentication, then proceed with login
                firebaseAuth.signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            // User login successful, navigate to MainActivity
                            navigateToMainActivity()
                        } else {
                            // User login failed, navigate to SignUpActivity
                            showToast("User not found. Please sign up.")
                            startActivity(Intent(this, Signup::class.java))
                        }
                    }
            }
        }

        // Set click listener for signup TextView
        binding.textView.setOnClickListener {
            // Navigate to SignUpActivity when signup TextView is clicked
            startActivity(Intent(this, Signup::class.java))
        }
    }

    // Method to navigate to MainActivity
    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish() // Finish the login activity to prevent going back to it when pressing back button
    }

    // Method to show Toast message
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
