package com.example.ese

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.ese.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Set up the custom toolbar
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // Set custom title centered at the top
        val toolbarTitle = layoutInflater.inflate(R.layout.toolbar_title_center, null) as TextView
        toolbarTitle.text = "HealthSync"
        toolbarTitle.setTextColor(resources.getColor(R.color.white)) // Set text color if needed
        supportActionBar?.setDisplayHomeAsUpEnabled(false)
        supportActionBar?.setDisplayShowCustomEnabled(true)
        supportActionBar?.customView = toolbarTitle

        // Load GIF into ImageView using Glide
        val medicineImageView = binding.medicinePurchaseButton
        val doctorImageView = binding.doctorGifImage
        val faqImageView = binding.faqButton // Assuming this is the ImageView for the FAQ button

        Glide.with(this)
            .asGif()
            .load(R.drawable.medicine)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .into(medicineImageView)

        Glide.with(this)
            .asGif()
            .load(R.drawable.doc)
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .into(doctorImageView)

        Glide.with(this)
            .asGif()
            .load(R.drawable.faq_icon) // Assuming this is the resource ID for the faq_icon.gif
            .diskCacheStrategy(DiskCacheStrategy.NONE)
            .into(faqImageView)

        // Set OnClickListener on medicineImageView to open URL
        medicineImageView.setOnClickListener {
            val url = "https://www.apollopharmacy.in/?utm_campaign=apollopharmacy&utm_source=icons_below_the_banner&utm_medium=digital"
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse(url)
            startActivity(intent)
        }

        // Set OnClickListener on doctorImageView to navigate to ConsultationActivity
        doctorImageView.setOnClickListener {
            navigateToConsultationActivity()
        }

        // Set OnClickListener on FAQ button ImageView
        faqImageView.setOnClickListener {
            navigateToFAQPage()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.drawer_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.nav_book_appointment -> {
                // Handle Book Appointment item click
                navigateToPatientDetails()
                true
            }
            R.id.nav_view_website -> {
                // Handle View Hospital Website item click
                openWebView("https://www.apollohospitals.com/") // Replace with the actual hospital website URL
                true
            }
            R.id.nav_calculate_bmi -> {
                // Handle Calculate BMI item click
                navigateToCalculateBMI()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun openWebView(url: String) {
        val intent = Intent(this, WebViewActivity::class.java)
        intent.putExtra("url", url)
        startActivity(intent)
    }

    private fun navigateToPatientDetails() {
        val intent = Intent(this, PatientDetailsActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToCalculateBMI() {
        val intent = Intent(this, InputDataActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToConsultationActivity() {
        val intent = Intent(this, ConsultationActivity::class.java)
        startActivity(intent)
    }

    private fun navigateToFAQPage() {
        val intent = Intent(this, FAQActivity::class.java)
        startActivity(intent)
    }
}
