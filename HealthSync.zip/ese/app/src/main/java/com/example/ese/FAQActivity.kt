package com.example.ese

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class FAQActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_faq)

        // Set up the custom toolbar
        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Set the title
        supportActionBar?.title = "FAQ"

        // Initialize TextViews for questions and answers
        val que1 = findViewById<TextView>(R.id.que1)
        val ans1 = findViewById<TextView>(R.id.ans1)
        val que2 = findViewById<TextView>(R.id.que2)
        val ans2 = findViewById<TextView>(R.id.ans2)
        val que3 = findViewById<TextView>(R.id.que3)
        val ans3 = findViewById<TextView>(R.id.ans3)
        val que4 = findViewById<TextView>(R.id.que4)
        val ans4 = findViewById<TextView>(R.id.ans4)

        // Set OnClickListener to toggle visibility of answers
        que1.setOnClickListener { toggleVisibility(ans1) }
        que2.setOnClickListener { toggleVisibility(ans2) }
        que3.setOnClickListener { toggleVisibility(ans3) }
        que4.setOnClickListener { toggleVisibility(ans4) }
    }

    // Method to toggle visibility of answers
    private fun toggleVisibility(textView: TextView) {
        textView.visibility = if (textView.visibility == TextView.VISIBLE) TextView.GONE else TextView.VISIBLE
    }
}
